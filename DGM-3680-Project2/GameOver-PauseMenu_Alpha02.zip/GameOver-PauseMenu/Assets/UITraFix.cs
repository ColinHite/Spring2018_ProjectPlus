﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UITraFix : MonoBehaviour {

	// Use this for initialization
	void Start () 
	{
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		
	}

	//Ok so I have three actions that need to take place.
	//I need to pause
	//I need to have a death case
	//I need to return the screen back to its original state
}
