﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChangeMenu : MonoBehaviour {

    public void ChangeVisable ()
    {
		
        Debug.Log("it got pressed");
    }
}
