﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuitGame_Hite : MonoBehaviour {

    public void QuitGame()
    {
        Application.Quit();
        print("you quit the game.");
    }

}
